let x = 200;
let y = 200;
function setup() {
  createCanvas(400, 400);
  background(200); //Background Color (R,G,B)
  stroke(0);
  fill("purple");
  rect(200, 0, 200, 200);
  fill("yellow");
  rect(0, 200, 200, 200);
  fill("red");
  circle(100,100,200);
  fill("green");
  circle(300,300,200);
  fill(255);
  
}

function draw() {
  strokeWeight(0);
  if(x < 200 && y > 200) fill("blue");
  if(x > 200 && y < 200) fill("yellow");
  if(dist(x,y,300,300)<100) fill("red");
  if(dist(x,y,100,100)<100) fill("green");
  circle(x,y,10);
  x = x + random(-10,10);
  y = y + random(-10,10);
}